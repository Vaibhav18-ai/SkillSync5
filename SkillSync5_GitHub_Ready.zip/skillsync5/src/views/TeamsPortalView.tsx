import React, { useState, useMemo } from 'react';
import { User, AVAILABLE_TRACKS } from '../types';
import { store } from '../services/storage';
import {
  Users,
  Search,
  Lock,
  ArrowRight,
  ShieldAlert,
  Award,
  Sparkles,
  CheckCircle2,
  Clock,
  Filter,
  ExternalLink,
  Code2,
  AlertCircle,
} from 'lucide-react';

interface TeamsPortalViewProps {
  user: User;
  onOpenTeamWorkspace: (teamId: number) => void;
  onToast: (msg: string) => void;
}

export const TeamsPortalView: React.FC<TeamsPortalViewProps> = ({
  user,
  onOpenTeamWorkspace,
  onToast,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterMine, setFilterMine] = useState(false);
  const [restrictedModalTeam, setRestrictedModalTeam] = useState<number | null>(null);

  const allTeams = store.getAllTeams();
  const myTeams = store.getMyTeams(user.id);
  const myPrimaryTeam = store.getStudentPrimaryTeam(user.id);

  // Enrich teams with members and project details
  const enrichedTeams = useMemo(() => {
    return allTeams.map((t) => {
      const details = store.getTeamDetails(t.teamId);
      const isMember = details ? details.members.some((m) => m.userId === user.id) : false;
      return {
        ...t,
        details,
        isMember,
      };
    });
  }, [allTeams, user.id]);

  const filteredTeams = useMemo(() => {
    return enrichedTeams.filter((t) => {
      if (filterMine && !t.isMember) return false;
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase();
      const matchComp = t.competitionName.toLowerCase().includes(q);
      const matchTeamNo = `team ${t.teamNo}`.toLowerCase().includes(q);
      const matchProj = t.details?.team.projectTitle?.toLowerCase().includes(q);
      const matchMember = t.details?.members.some((m) => m.name.toLowerCase().includes(q));
      return matchComp || matchTeamNo || matchProj || matchMember;
    });
  }, [enrichedTeams, filterMine, searchQuery]);

  const handleAttemptAccess = (teamId: number, isMember: boolean, teamNo: number) => {
    if (user.role === 'coordinator') {
      setRestrictedModalTeam(teamNo);
      onToast(`Access Prohibited: Coordinators cannot enter private team workspaces.`);
      return;
    }

    if (!isMember) {
      setRestrictedModalTeam(teamNo);
      onToast(`Access Denied: Only members of Team ${teamNo} can access this dashboard.`);
      return;
    }

    onOpenTeamWorkspace(teamId);
  };

  return (
    <div className="space-y-6">
      {/* Portal Top Banner */}
      <div className="card p-6 bg-gradient-to-r from-slate-900 via-indigo-950 to-teal-950 text-white border-0 shadow-lg relative overflow-hidden">
        <div className="absolute right-0 top-0 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5 text-teal-300 text-xs font-semibold">
              <Users className="w-4 h-4" /> Cohort Teams Directory
            </div>
            <h1 className="text-2xl font-black tracking-tight text-white flex items-center gap-3">
              <span>Teams Portal</span>
              <span className="text-xs font-extrabold px-3 py-1 rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/30">
                {allTeams.length} Formed Teams
              </span>
            </h1>
            <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">
              Explore all algorithm-balanced teams formed across active competitions. Under privacy and fairness governance,{' '}
              <b>each team dashboard is strictly private and accessible only by that team's confirmed members</b>.
            </p>
          </div>

          {/* Quick User Team Status */}
          {user.role === 'student' && (
            <div className="bg-white/10 backdrop-blur-md p-3.5 rounded-xl border border-white/15 max-w-xs text-xs">
              <div className="text-[11px] text-teal-200 uppercase font-bold tracking-wider mb-0.5">
                Your Assignment Status
              </div>
              {myPrimaryTeam ? (
                <div>
                  <div className="font-bold text-white text-sm">
                    Team {myPrimaryTeam.teamNo} ({myPrimaryTeam.competitionName})
                  </div>
                  <button
                    type="button"
                    onClick={() => onOpenTeamWorkspace(myPrimaryTeam.teamId)}
                    className="mt-2 text-xs font-bold bg-teal-500 hover:bg-teal-400 text-slate-950 px-3 py-1.5 rounded-lg flex items-center gap-1 transition shadow-sm cursor-pointer w-full justify-center"
                  >
                    <span>Open My Team Dashboard</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <div className="text-slate-300">
                  <span>Not currently assigned to a team. Register for competitions in the Student Portal!</span>
                </div>
              )}
            </div>
          )}

          {user.role === 'coordinator' && (
            <div className="bg-purple-900/40 backdrop-blur-md p-3.5 rounded-xl border border-purple-400/30 text-xs text-purple-200">
              <div className="font-bold text-white flex items-center gap-1.5 mb-1">
                <Lock className="w-4 h-4 text-purple-300" />
                <span>Coordinator Privacy Rule</span>
              </div>
              <p className="text-[11px] text-purple-200/90 leading-tight">
                Team workspaces are private to students. Manage algorithms, roster balance, and grade deliverables from the{' '}
                <b>Team Coordinator Portal</b>.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Search, Filter, and Controls Bar */}
      <div className="card p-4 bg-white border border-slate-200 space-y-3">
        <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
          <div className="relative w-full sm:max-w-md">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
              <Search className="w-4 h-4" />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by team number, project, or member name..."
              className="w-full text-xs pr-3 py-2.5 bg-slate-50 rounded-xl border border-slate-200 focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal-500 search-input-field"
              style={{ paddingLeft: '2.75rem' }}
            />
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            {user.role === 'student' && (
              <button
                type="button"
                onClick={() => setFilterMine(!filterMine)}
                className={`text-xs px-3 py-2 rounded-xl font-bold border transition cursor-pointer flex items-center gap-1.5 ${
                  filterMine
                    ? 'bg-teal-600 text-white border-teal-600 shadow-xs'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <span>⭐ My Teams Only ({myTeams.length})</span>
              </button>
            )}
            <span className="text-xs text-slate-500">
              Showing <b>{filteredTeams.length}</b> of <b>{allTeams.length}</b> teams
            </span>
          </div>
        </div>
      </div>

      {/* Teams Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredTeams.map((team) => {
          const details = team.details;
          const isMember = team.isMember;

          return (
            <div
              key={team.teamId}
              className={`card p-5 bg-white border flex flex-col justify-between transition-all hover:shadow-md ${
                isMember
                  ? 'border-teal-400 ring-2 ring-teal-500/20 bg-teal-50/10'
                  : 'border-slate-200'
              }`}
            >
              <div className="space-y-3">
                {/* Team Card Header */}
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-black px-2 py-0.5 rounded bg-slate-100 text-slate-800 border border-slate-200">
                        Team {team.teamNo}
                      </span>
                      {isMember && (
                        <span className="text-[10px] font-extrabold px-2 py-0.5 rounded bg-teal-100 text-teal-800 border border-teal-200 flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3 text-teal-600" /> My Team
                        </span>
                      )}
                    </div>
                    <h3 className="font-bold text-slate-900 text-sm line-clamp-1">
                      {details?.team.projectTitle || `${team.competitionName} Sprint Team`}
                    </h3>
                    <div className="text-[11px] text-slate-500 line-clamp-1">{team.competitionName}</div>
                  </div>

                  <div className="text-right shrink-0">
                    <div className="text-xs font-black text-teal-700">{team.avgScore.toFixed(2)}</div>
                    <div className="text-[10px] text-slate-400">Team Avg</div>
                  </div>
                </div>

                {/* Project Description */}
                <p className="text-xs text-slate-600 line-clamp-2">
                  {details?.team.projectDescription ||
                    'Developing high-performance balanced solution with robust sprint architecture.'}
                </p>

                {/* Team Roster */}
                <div>
                  <div className="text-[10px] uppercase font-bold text-slate-400 mb-1">
                    Confirmed Teammates ({details?.members.length || team.memberCount})
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {details?.members.map((m) => {
                      const isMe = m.userId === user.id;
                      return (
                        <span
                          key={m.userId}
                          className={`text-xs px-2 py-0.5 rounded-md border flex items-center gap-1 ${
                            isMe
                              ? 'bg-teal-100 border-teal-300 text-teal-900 font-bold'
                              : m.isLeader
                              ? 'bg-amber-50 border-amber-200 text-amber-800 font-semibold'
                              : 'bg-slate-50 border-slate-200 text-slate-700'
                          }`}
                        >
                          <span>{m.name}</span>
                          {m.isLeader && <span className="text-[9px] text-amber-700 font-bold">★ Leader</span>}
                          {isMe && <span className="text-[9px] text-teal-700 font-bold">(You)</span>}
                        </span>
                      );
                    })}
                  </div>
                </div>

                {/* Tasks & Deliverable Stats */}
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                  <div className="flex items-center gap-3">
                    <span>
                      📋 <b>{details?.tasks.length || 0}</b> tasks
                    </span>
                    <span>
                      🎯 <b>{details?.milestones.length || 0}</b> milestones
                    </span>
                  </div>
                  <span
                    className={`font-semibold ${
                      details?.team.isSubmitted ? 'text-teal-700' : 'text-slate-400'
                    }`}
                  >
                    {details?.team.isSubmitted ? 'Deliverable Submitted' : 'Sprint In Progress'}
                  </span>
                </div>
              </div>

              {/* Action Access Button */}
              <div className="pt-4 mt-2">
                {isMember ? (
                  <button
                    type="button"
                    onClick={() => onOpenTeamWorkspace(team.teamId)}
                    className="btn w-full text-xs py-2 font-bold flex items-center justify-center gap-2 shadow-sm cursor-pointer"
                  >
                    <span>Open My Team Dashboard</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                ) : user.role === 'coordinator' ? (
                  <button
                    type="button"
                    onClick={() => handleAttemptAccess(team.teamId, false, team.teamNo)}
                    className="w-full text-xs py-2 px-3 rounded-xl border border-slate-200 bg-slate-50 text-slate-500 font-semibold flex items-center justify-center gap-1.5 hover:bg-slate-100 transition cursor-pointer"
                  >
                    <Lock className="w-3.5 h-3.5 text-slate-400" />
                    <span>Private Team Workspace</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => handleAttemptAccess(team.teamId, false, team.teamNo)}
                    className="w-full text-xs py-2 px-3 rounded-xl border border-slate-200 bg-slate-50 text-slate-500 font-semibold flex items-center justify-center gap-1.5 hover:bg-slate-100 transition cursor-pointer"
                  >
                    <Lock className="w-3.5 h-3.5 text-slate-400" />
                    <span>Teammates Only (Restricted)</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}

        {filteredTeams.length === 0 && (
          <div className="col-span-full py-12 text-center card bg-white border border-slate-200 text-slate-500 text-xs">
            No teams found matching your query.
          </div>
        )}
      </div>

      {/* Restricted Access Modal */}
      {restrictedModalTeam !== null && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 p-6 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-xl bg-rose-50 text-rose-600 border border-rose-200 flex items-center justify-center mx-auto">
              <ShieldAlert className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1">
              <h3 className="font-bold text-slate-900 text-base">
                Team {restrictedModalTeam} Dashboard Restricted
              </h3>
              <p className="text-xs text-slate-500">
                Private Workspace Governance & Team Confidentiality
              </p>
            </div>

            <div className="text-xs text-slate-700 bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
              {user.role === 'coordinator' ? (
                <p>
                  <b>Coordinator Notice:</b> Individual Team Dashboards (Kanban boards, internal tasks, sprint
                  scratchpads) are exclusively accessible to <b>enrolled students on that team</b>. Coordinators
                  review team rosters, algorithm metrics, and project deliverables through the{' '}
                  <b>Team Coordinator Portal</b>.
                </p>
              ) : (
                <p>
                  <b>Student Notice:</b> You are logged in as <b>{user.name}</b>. You are not a member of Team{' '}
                  {restrictedModalTeam}. Only confirmed teammates have permission to enter and modify this team's
                  workspace.
                </p>
              )}
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setRestrictedModalTeam(null)}
                className="btn text-xs py-1.5 px-4 font-semibold"
              >
                Understood
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
