export type Role = 'student' | 'coordinator' | 'admin';
export type CompetitionType = 'dsa' | 'ml' | 'hardware' | 'web' | 'cyber' | 'other';
export type CompetitionStatus =
  | 'draft'
  | 'registration_open'
  | 'registration_closed'
  | 'teams_proposed'
  | 'under_review'
  | 'finalized'
  | 'ongoing'
  | 'completed';
export type FormationMode = 'balanced' | 'preference' | 'self';
export type ScaleTier = 'school' | 'regional' | 'national' | 'global';
export type TaskStatus = 'todo' | 'doing' | 'done';

export interface User {
  id: number;
  name: string;
  email: string;
  role: Role;
}

export interface Skill {
  id: number;
  name: string;
  category?: string;
}

export interface StudentSkill {
  userId: number;
  skillId: number;
  proficiency: number;
  experienceScore: number;
  assessmentScore: number;
}

export interface PortfolioProject {
  id: string;
  title: string;
  repoUrl: string;
  demoUrl?: string;
  description?: string;
  techStack: string[];
}

export interface StudentProfile {
  userId: number;
  bio?: string;
  availabilityHours: number;
  preferredRole?: string;
  githubUrl?: string;
  portfolioProjects?: PortfolioProject[];
  certifications?: string[];
  achievements?: string[];
}

export interface CompetitionRequirement {
  skillId: number;
  skill: string;
  weight: number;
  minLevel: number;
  mandatory: boolean;
}

export interface Competition {
  id: number;
  coordinatorId: number;
  name: string;
  description: string;
  compType: CompetitionType;
  compTypes: string[];
  teamSize: number;
  minTeamSize: number;
  maxTeamSize: number;
  numTeams: number;
  scaleTier: ScaleTier;
  fairnessTolerance: number;
  formationMode: FormationMode;
  status: CompetitionStatus;
  deadline?: string;
  joinCode: string;
  requirements: CompetitionRequirement[];
  myFit?: number;
  eligible?: boolean;
  missing?: string[];
  myStatus?: 'confirmed' | 'pending' | 'rejected' | 'withdrawn' | null;
  myApplication?: { status: string; wantsToLead: boolean } | null;
}

export interface CompetitionApplication {
  competitionId: number;
  userId: number;
  status: 'pending' | 'confirmed' | 'rejected' | 'withdrawn';
  wantsToLead: boolean;
  createdAt: string;
}

export interface TeammatePreference {
  competitionId: number;
  userId: number;
  otherUserId: number;
  kind: 'prefer' | 'avoid';
}

export interface Team {
  id: number;
  competitionId: number;
  teamNo: number;
  leaderId: number | null;
  avgScore: number;
  competitionName?: string;
  projectTitle?: string;
  projectDescription?: string;
  projectRepoUrl?: string;
  isSubmitted?: boolean;
  evaluationScore?: number;
  feedback?: string;
}

export interface TeamMember {
  id: number;
  teamId: number;
  competitionId: number;
  userId: number;
  isLeader: boolean;
  score: number;
}

export interface Task {
  id: number;
  teamId: number;
  title: string;
  description?: string;
  assigneeId?: number | null;
  estimatedHours: number;
  deadline?: string;
  status: TaskStatus;
  createdAt: string;
}

export interface Milestone {
  id: number;
  teamId: number;
  title: string;
  dueDate?: string;
  done: boolean;
}

export interface CandidateMember {
  userId: number;
  name: string;
  score: number;
  isLeader: boolean;
}

export interface CandidateTeam {
  teamNo: number;
  avg: number;
  members: CandidateMember[];
}

export interface TeamMetrics {
  spread: number;
  withinTolerance: boolean;
  avgs: number[];
  preferMet: number;
  preferTotal: number;
  avoidViolations: number;
  skillGaps: Record<string, number>;
}

export interface TeamOption {
  teams: CandidateTeam[];
  metrics: TeamMetrics;
}

export interface RecommendationRun {
  runId: number;
  competitionId: number;
  options: TeamOption[];
  warnings: string[];
  students: number;
  tol: number;
}

export interface FairnessReport {
  competition: string;
  tolerance: number;
  trials: number;
  ours: {
    spread: number;
    withinTolerance: boolean;
    preferMet: number;
    preferTotal: number;
    avoidViolations: number;
    skillGap: number;
  };
  random: {
    avgSpread: number;
    pctWithinTolerance: number;
    avgPreferMet: number;
    avgAvoidViolations: number;
    avgSkillGap: number;
  };
}

export const AVAILABLE_TRACKS: Array<{ id: CompetitionType; name: string; icon: string }> = [
  { id: 'ml', name: 'AI / Machine Learning', icon: '🤖' },
  { id: 'web', name: 'Web Development', icon: '🌐' },
  { id: 'dsa', name: 'DSA / Coding', icon: '💻' },
  { id: 'hardware', name: 'Hardware / IoT', icon: '🔌' },
  { id: 'cyber', name: 'Cybersecurity', icon: '🛡️' },
  { id: 'other', name: 'Other', icon: '✨' },
];

export const SCALE_TIERS: Array<{
  id: ScaleTier;
  label: string;
  icon: string;
  range: string;
  defaultTeams: number;
  minSize: number;
  targetSize: number;
  maxSize: number;
}> = [
  { id: 'school', label: 'School / Class', icon: '🏫', range: '20–100 students', defaultTeams: 5, minSize: 3, targetSize: 5, maxSize: 6 },
  { id: 'regional', label: 'Regional', icon: '📍', range: '100–500 students', defaultTeams: 20, minSize: 3, targetSize: 5, maxSize: 6 },
  { id: 'national', label: 'National', icon: '🇮🇳', range: '500–5,000 students', defaultTeams: 100, minSize: 3, targetSize: 5, maxSize: 6 },
  { id: 'global', label: 'Global', icon: '🌍', range: '5,000+ students', defaultTeams: 250, minSize: 3, targetSize: 5, maxSize: 6 },
];
