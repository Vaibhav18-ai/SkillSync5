import React, { useEffect, useRef } from 'react';
import Chart from 'chart.js/auto';

interface RadarChartProps {
  labels: string[];
  data: number[];
}

export const RadarChart: React.FC<RadarChartProps> = ({ labels, data }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const chartRef = useRef<Chart | null>(null);

  useEffect(() => {
    if (!canvasRef.current) return;
    chartRef.current?.destroy();
    chartRef.current = new Chart(canvasRef.current, {
      type: 'radar',
      data: {
        labels,
        datasets: [{
          label: 'Skill proficiency',
          data,
          borderColor: '#0d9488',
          backgroundColor: 'rgba(13, 148, 136, 0.18)',
          pointBackgroundColor: '#0d9488',
          pointRadius: 3,
          borderWidth: 2,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: { r: { min: 0, max: 10, ticks: { stepSize: 2, backdropColor: 'transparent' } } },
      },
    });
    return () => { chartRef.current?.destroy(); chartRef.current = null; };
  }, [labels, data]);

  return <div className="w-full h-[240px]"><canvas ref={canvasRef} role="img" aria-label="Student skill strengths" /></div>;
};
