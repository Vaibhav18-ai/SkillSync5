import React, { useEffect, useRef } from 'react';
import Chart from 'chart.js/auto';

interface BarChartProps {
  labels: string[];
  data: number[];
  labelName?: string;
  minY?: number;
  maxY?: number;
}

export const BarChart: React.FC<BarChartProps> = ({ labels, data, labelName = 'Score', minY = 0, maxY = 10 }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const chartRef = useRef<Chart | null>(null);

  useEffect(() => {
    if (!canvasRef.current) return;
    chartRef.current?.destroy();
    chartRef.current = new Chart(canvasRef.current, {
      type: 'bar',
      data: {
        labels,
        datasets: [{
          label: labelName,
          data,
          backgroundColor: 'rgba(13, 148, 136, 0.78)',
          borderColor: '#0d9488',
          borderWidth: 1,
          borderRadius: 7,
          maxBarThickness: 48,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          y: { beginAtZero: minY === 0, min: minY, max: maxY, ticks: { precision: 1 } },
          x: { grid: { display: false } },
        },
      },
    });
    return () => { chartRef.current?.destroy(); chartRef.current = null; };
  }, [labels, data, labelName, minY, maxY]);

  return <div className="h-full w-full min-h-[180px]"><canvas ref={canvasRef} role="img" aria-label={labelName} /></div>;
};
