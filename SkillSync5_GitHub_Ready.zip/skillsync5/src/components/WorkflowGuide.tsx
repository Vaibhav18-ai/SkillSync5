import React from 'react';
import { X, UserRound, ClipboardList, Sparkles, UsersRound, CheckCircle2, BriefcaseBusiness, Flag } from 'lucide-react';

interface WorkflowGuideProps {
  isOpen: boolean;
  onClose: () => void;
}

const steps = [
  { title: 'Student onboarding', description: 'Students register, complete a profile, add portfolio evidence, and receive transparent skill scores.', icon: UserRound },
  { title: 'Competition setup', description: 'The coordinator configures the event, required skills, weights, eligibility, team size, and fairness tolerance.', icon: ClipboardList },
  { title: 'Personalized recommendations', description: 'SkillSync matches student competencies and interests to relevant competitions.', icon: Sparkles },
  { title: 'Preferences and leadership', description: 'Students volunteer to lead and submit teammate preferences before team generation.', icon: UsersRound },
  { title: 'Balanced team generation', description: 'The engine balances team scores and skill coverage while respecting hard constraints and preferences where possible.', icon: Sparkles },
  { title: 'Review and finalization', description: 'Students can review proposals and request changes; authorized coordinators resolve exceptions and finalize teams.', icon: CheckCircle2 },
  { title: 'Private team workspace', description: 'Confirmed members plan the project, assign roles, manage tasks, and track milestones.', icon: BriefcaseBusiness },
  { title: 'Submission and evaluation', description: 'Teams submit their work; the event closes and feedback is collected for future evaluation.', icon: Flag },
];

export const WorkflowGuide: React.FC<WorkflowGuideProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/60 p-4" role="dialog" aria-modal="true" aria-labelledby="workflow-title" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <section className="w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-2xl bg-white shadow-2xl">
        <header className="sticky top-0 z-10 flex items-center justify-between border-b border-slate-200 bg-white/95 px-6 py-4 backdrop-blur">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.18em] text-teal-700">SkillSync</p>
            <h2 id="workflow-title" className="mt-1 text-xl font-extrabold text-slate-900">End-to-end workflow</h2>
          </div>
          <button type="button" onClick={onClose} className="rounded-xl p-2 text-slate-500 hover:bg-slate-100 hover:text-slate-900" aria-label="Close workflow guide"><X className="h-5 w-5" /></button>
        </header>
        <div className="grid gap-3 p-5 sm:grid-cols-2">
          {steps.map((step, index) => {
            const Icon = step.icon;
            return (
              <article key={step.title} className="rounded-xl border border-slate-200 bg-slate-50/70 p-4">
                <div className="flex items-start gap-3">
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-teal-100 text-teal-700"><Icon className="h-4 w-4" /></div>
                  <div>
                    <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Step {index + 1}</p>
                    <h3 className="mt-0.5 font-bold text-slate-900">{step.title}</h3>
                    <p className="mt-1 text-sm leading-6 text-slate-600">{step.description}</p>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
        <div className="flex justify-end border-t border-slate-200 px-6 py-4">
          <button type="button" onClick={onClose} className="rounded-xl bg-teal-700 px-4 py-2.5 text-sm font-bold text-white hover:bg-teal-800">Close guide</button>
        </div>
      </section>
    </div>
  );
};
