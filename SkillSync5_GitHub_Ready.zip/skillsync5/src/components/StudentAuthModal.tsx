import React, { useState } from 'react';
import { User, PortfolioProject } from '../types';
import { store } from '../services/storage';
import {
  UserPlus,
  LogIn,
  X,
  Code2,
  FolderGit2,
  Plus,
  Trash2,
  ExternalLink,
  Search,
  CheckCircle2,
  AlertCircle,
  Briefcase,
  Clock,
  Award,
} from 'lucide-react';

interface StudentAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectUser: (user: User) => void;
  onToast: (msg: string) => void;
}

export const StudentAuthModal: React.FC<StudentAuthModalProps> = ({
  isOpen,
  onClose,
  onSelectUser,
  onToast,
}) => {
  const [activeTab, setActiveTab] = useState<'register' | 'login'>('register');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Registration Form State
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regRole, setRegRole] = useState('fullstack');
  const [regHours, setRegHours] = useState(15);
  const [regBio, setRegBio] = useState('');
  const [regGithub, setRegGithub] = useState('');
  const [regCertifications, setRegCertifications] = useState('');

  // Skills rating state
  const availableSkills = store.getState().skills;
  const [skillRatings, setSkillRatings] = useState<Record<number, number>>({
    1: 4, // Python
    2: 4, // React
    3: 3, // TypeScript
    4: 3, // Node.js
    8: 3, // PostgreSQL
    10: 4, // Machine Learning
  });

  // Portfolio Projects State
  const [portfolioProjects, setPortfolioProjects] = useState<PortfolioProject[]>([
    {
      id: 'proj-init-1',
      title: 'Fullstack Distributed Task Queue',
      repoUrl: 'https://github.com/developer/task-queue',
      demoUrl: 'https://task-queue-demo.test',
      description: 'Asynchronous job worker processing 5,000 tasks/sec with Redis broker and React live dashboard.',
      techStack: ['TypeScript', 'React', 'Node.js', 'Redis'],
    },
  ]);

  // Project item draft
  const [newProjTitle, setNewProjTitle] = useState('');
  const [newProjRepo, setNewProjRepo] = useState('');
  const [newProjDemo, setNewProjDemo] = useState('');
  const [newProjDesc, setNewProjDesc] = useState('');
  const [newProjTech, setNewProjTech] = useState('');
  const [showAddProjectForm, setShowAddProjectForm] = useState(false);

  // Login Form State
  const [loginEmail, setLoginEmail] = useState('');
  const [loginSearch, setLoginSearch] = useState('');

  if (!isOpen) return null;

  const handleAddProject = () => {
    if (!newProjTitle.trim() || !newProjRepo.trim()) {
      setErrorMsg('Project title and repository URL are required.');
      return;
    }

    const techArray = newProjTech
      ? newProjTech.split(',').map((t) => t.trim()).filter(Boolean)
      : ['TypeScript', 'React'];

    const project: PortfolioProject = {
      id: `proj-${Date.now()}`,
      title: newProjTitle.trim(),
      repoUrl: newProjRepo.trim(),
      demoUrl: newProjDemo.trim() || undefined,
      description: newProjDesc.trim() || 'Collaborative software engineering project.',
      techStack: techArray,
    };

    setPortfolioProjects((prev) => [...prev, project]);
    setNewProjTitle('');
    setNewProjRepo('');
    setNewProjDemo('');
    setNewProjDesc('');
    setNewProjTech('');
    setShowAddProjectForm(false);
    setErrorMsg(null);
  };

  const handleRemoveProject = (id: string) => {
    setPortfolioProjects((prev) => prev.filter((p) => p.id !== id));
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!regName.trim()) {
      setErrorMsg('Full Name is required.');
      return;
    }
    if (!regEmail.trim()) {
      setErrorMsg('Email address is required.');
      return;
    }
    if (!regEmail.includes('@') || !regEmail.includes('.')) {
      setErrorMsg('Please enter a valid email address.');
      return;
    }

    try {
      const skillsToSave = Object.entries(skillRatings).map(([sId, rating]) => ({
        skillId: Number(sId),
        proficiency: rating,
        experienceScore: Math.min(10, rating * 2),
      }));

      const certs = regCertifications
        ? regCertifications.split(',').map((c) => c.trim()).filter(Boolean)
        : [];

      const newUser = store.registerStudent({
        name: regName.trim(),
        email: regEmail.trim(),
        preferredRole: regRole,
        availabilityHours: Number(regHours),
        bio: regBio.trim(),
        githubUrl: regGithub.trim(),
        skills: skillsToSave,
        portfolioProjects,
        certifications: certs,
      });

      onToast(`Student registered! Welcome, ${newUser.name}.`);
      onSelectUser(newUser);
      onClose();
    } catch (err: unknown) {
      if (err instanceof Error) {
        setErrorMsg(err.message);
      } else {
        setErrorMsg('Failed to register student. Please check input details.');
      }
    }
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!loginEmail.trim()) {
      setErrorMsg('Please enter your student email address.');
      return;
    }

    const user = store.findUserByEmail(loginEmail);
    if (!user) {
      setErrorMsg(`No registered account found for "${loginEmail}". Please check spelling or register below.`);
      return;
    }

    onSelectUser(user);
    onToast(`Logged in as ${user.name} (${user.role}).`);
    onClose();
  };

  const allUsers = store.getState().users;
  const filteredUsers = allUsers.filter((u) => {
    if (!loginSearch) return true;
    return (
      u.name.toLowerCase().includes(loginSearch.toLowerCase()) ||
      u.email.toLowerCase().includes(loginSearch.toLowerCase())
    );
  });

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 flex flex-col max-h-[92vh] overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Top Header */}
        <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-teal-600 text-white flex items-center justify-center shadow-md shadow-teal-600/20">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                Student Portal Authentication
              </h2>
              <p className="text-xs text-slate-500">
                Register new student with full portfolio details or sign in to your dashboard
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-slate-200 bg-slate-100/70 p-1 shrink-0">
          <button
            type="button"
            onClick={() => {
              setActiveTab('register');
              setErrorMsg(null);
            }}
            className={`flex-1 py-2 text-xs font-bold rounded-lg flex items-center justify-center gap-2 transition cursor-pointer ${
              activeTab === 'register'
                ? 'bg-white text-teal-800 shadow-xs border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <UserPlus className="w-4 h-4 text-teal-600" />
            <span>Register New Student (With Portfolio)</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveTab('login');
              setErrorMsg(null);
            }}
            className={`flex-1 py-2 text-xs font-bold rounded-lg flex items-center justify-center gap-2 transition cursor-pointer ${
              activeTab === 'login'
                ? 'bg-white text-teal-800 shadow-xs border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <LogIn className="w-4 h-4 text-blue-600" />
            <span>Student Sign In / Switch Account</span>
          </button>
        </div>

        {/* Error Alert */}
        {errorMsg && (
          <div className="mx-5 mt-3 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Modal Scrollable Body */}
        <div className="p-5 overflow-y-auto space-y-5">
          {activeTab === 'register' ? (
            <form onSubmit={handleRegisterSubmit} className="space-y-5">
              {/* Basic Information */}
              <div className="space-y-3">
                <h3 className="text-xs font-bold uppercase tracking-wider text-teal-800 flex items-center gap-1.5">
                  <span>1.</span> Student Profile Information
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Full Name <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={regName}
                      onChange={(e) => setRegName(e.target.value)}
                      placeholder="e.g. Priyanshu Varma"
                      className="w-full text-xs font-medium"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Student Email Address <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="email"
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      placeholder="e.g. priyanshu.v@university.edu"
                      className="w-full text-xs font-medium"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Specialization / Preferred Role
                    </label>
                    <select
                      value={regRole}
                      onChange={(e) => setRegRole(e.target.value)}
                      className="w-full text-xs font-medium"
                    >
                      <option value="ml">AI / Machine Learning</option>
                      <option value="fullstack">Fullstack Web</option>
                      <option value="frontend">Frontend Developer</option>
                      <option value="backend">Backend & Distributed Systems</option>
                      <option value="hardware">Hardware & Embedded IoT</option>
                      <option value="cyber">Cybersecurity & Infra</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Weekly Availability: <b className="text-teal-700">{regHours} hours / week</b>
                    </label>
                    <input
                      type="range"
                      min="5"
                      max="40"
                      step="5"
                      value={regHours}
                      onChange={(e) => setRegHours(Number(e.target.value))}
                      className="w-full accent-teal-600 mt-2"
                    />
                    <div className="flex justify-between text-[10px] text-slate-400">
                      <span>5h (Part-time)</span>
                      <span>20h (Active)</span>
                      <span>40h (Intensive)</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      GitHub Profile URL / Portfolio Link
                    </label>
                    <input
                      type="url"
                      value={regGithub}
                      onChange={(e) => setRegGithub(e.target.value)}
                      placeholder="https://github.com/username or https://portfolio.dev"
                      className="w-full text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Certifications / Honors
                    </label>
                    <input
                      type="text"
                      value={regCertifications}
                      onChange={(e) => setRegCertifications(e.target.value)}
                      placeholder="e.g. AWS Solutions Architect, Kaggle Expert"
                      className="w-full text-xs"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Student Bio / Engineering Interests
                  </label>
                  <textarea
                    rows={2}
                    value={regBio}
                    onChange={(e) => setRegBio(e.target.value)}
                    placeholder="Tell prospective teammates about your projects, strengths, and what domain challenges you enjoy solving..."
                    className="w-full text-xs"
                  />
                </div>
              </div>

              {/* Technical Skills Assessment */}
              <div className="space-y-3 pt-2 border-t border-slate-100">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-teal-800 flex items-center gap-1.5">
                    <span>2.</span> Technical Skill Ratings (1 to 5)
                  </h3>
                  <span className="text-[11px] text-slate-400">Used by fairness algorithm for balanced teams</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto p-2 bg-slate-50 rounded-xl border border-slate-200">
                  {availableSkills.map((sk) => {
                    const currentProf = skillRatings[sk.id] || 2;
                    return (
                      <div
                        key={sk.id}
                        className="bg-white p-2 rounded-lg border border-slate-200 flex items-center justify-between text-xs"
                      >
                        <div className="min-w-0 pr-2">
                          <span className="font-semibold text-slate-800 block truncate">{sk.name}</span>
                          <span className="text-[10px] text-slate-400">{sk.category}</span>
                        </div>
                        <div className="flex items-center gap-1 shrink-0">
                          {[1, 2, 3, 4, 5].map((lvl) => (
                            <button
                              key={lvl}
                              type="button"
                              onClick={() => {
                                setSkillRatings((prev) => ({ ...prev, [sk.id]: lvl }));
                              }}
                              className={`w-6 h-6 rounded-md text-[11px] font-bold transition cursor-pointer ${
                                currentProf >= lvl
                                  ? 'bg-teal-600 text-white'
                                  : 'bg-slate-100 text-slate-400 hover:bg-slate-200'
                              }`}
                            >
                              {lvl}
                            </button>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Portfolio Projects Section */}
              <div className="space-y-3 pt-2 border-t border-slate-100">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xs font-bold uppercase tracking-wider text-teal-800 flex items-center gap-1.5">
                      <span>3.</span> Portfolio Projects ({portfolioProjects.length})
                    </h3>
                    <p className="text-[11px] text-slate-500">
                      Showcase past repositories and live demos so coordinators & teammates can inspect your track record.
                    </p>
                  </div>
                  {!showAddProjectForm && (
                    <button
                      type="button"
                      onClick={() => setShowAddProjectForm(true)}
                      className="btn ghost text-xs py-1 px-2.5 flex items-center gap-1"
                    >
                      <Plus className="w-3.5 h-3.5 text-teal-600" />
                      <span>Add Project</span>
                    </button>
                  )}
                </div>

                {/* Existing Projects List */}
                <div className="space-y-2">
                  {portfolioProjects.map((p) => (
                    <div
                      key={p.id}
                      className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-start justify-between gap-3 text-xs"
                    >
                      <div className="space-y-1">
                        <div className="font-bold text-slate-900 flex items-center gap-2">
                          <FolderGit2 className="w-4 h-4 text-teal-600 shrink-0" />
                          <span>{p.title}</span>
                        </div>
                        <p className="text-slate-600 text-[11px] line-clamp-2">{p.description}</p>
                        <div className="flex flex-wrap items-center gap-1.5 pt-1">
                          {p.techStack.map((tech) => (
                            <span
                              key={tech}
                              className="text-[10px] px-2 py-0.5 rounded-md bg-white border border-slate-200 font-medium text-slate-700"
                            >
                              {tech}
                            </span>
                          ))}
                          <a
                            href={p.repoUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="text-[11px] text-teal-700 hover:underline flex items-center gap-0.5 ml-2 font-medium"
                          >
                            <span>Repo</span>
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleRemoveProject(p.id)}
                        className="text-slate-400 hover:text-rose-600 p-1 rounded-lg transition"
                        title="Remove project"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}

                  {portfolioProjects.length === 0 && !showAddProjectForm && (
                    <div className="p-4 rounded-xl border border-dashed border-slate-300 text-center text-xs text-slate-500">
                      No portfolio projects added yet. Click "+ Add Project" to highlight your work!
                    </div>
                  )}
                </div>

                {/* Inline Add Project Form */}
                {showAddProjectForm && (
                  <div className="p-4 rounded-xl bg-teal-50/50 border border-teal-200 space-y-3 animate-in fade-in duration-150 text-xs">
                    <h4 className="font-bold text-slate-900 flex items-center justify-between">
                      <span>Add New Portfolio Project</span>
                      <button
                        type="button"
                        onClick={() => setShowAddProjectForm(false)}
                        className="text-slate-400 hover:text-slate-700"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </h4>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">
                          Project Title <span className="text-rose-500">*</span>
                        </label>
                        <input
                          type="text"
                          value={newProjTitle}
                          onChange={(e) => setNewProjTitle(e.target.value)}
                          placeholder="e.g. Distributed Consensus Engine"
                          className="w-full text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">
                          GitHub Repo URL <span className="text-rose-500">*</span>
                        </label>
                        <input
                          type="url"
                          value={newProjRepo}
                          onChange={(e) => setNewProjRepo(e.target.value)}
                          placeholder="https://github.com/user/project"
                          className="w-full text-xs"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">
                          Live Demo URL (Optional)
                        </label>
                        <input
                          type="url"
                          value={newProjDemo}
                          onChange={(e) => setNewProjDemo(e.target.value)}
                          placeholder="https://myproject.dev"
                          className="w-full text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">
                          Tech Stack (Comma-separated)
                        </label>
                        <input
                          type="text"
                          value={newProjTech}
                          onChange={(e) => setNewProjTech(e.target.value)}
                          placeholder="Python, PyTorch, FastAPI, React"
                          className="w-full text-xs"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">
                        Description / Technical Highlights
                      </label>
                      <textarea
                        rows={2}
                        value={newProjDesc}
                        onChange={(e) => setNewProjDesc(e.target.value)}
                        placeholder="Key technical accomplishments, architectural decisions, and performance metrics..."
                        className="w-full text-xs"
                      />
                    </div>

                    <div className="flex justify-end gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => setShowAddProjectForm(false)}
                        className="btn ghost text-xs py-1.5 px-3"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        onClick={handleAddProject}
                        className="btn text-xs py-1.5 px-3 font-semibold"
                      >
                        Save Project to Portfolio
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Submit Button */}
              <div className="pt-3 border-t border-slate-200 flex items-center justify-between gap-3">
                <span className="text-[11px] text-slate-500">
                  Account is immediately saved in browser storage (no code changes required).
                </span>
                <button
                  type="submit"
                  className="btn py-2.5 px-5 font-bold text-xs shadow-md cursor-pointer"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>Create Account & Sign In</span>
                </button>
              </div>
            </form>
          ) : (
            /* Login / Account Switcher Tab */
            <div className="space-y-5">
              {/* Direct Email Sign In */}
              <form onSubmit={handleLoginSubmit} className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
                <h3 className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                  <LogIn className="w-4 h-4 text-teal-600" />
                  <span>Direct Sign In by Email</span>
                </h3>
                <div className="flex gap-2">
                  <input
                    type="email"
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="Enter registered student email (e.g. aarav.patel2@skillsync.test)..."
                    className="flex-1 text-xs"
                  />
                  <button
                    type="submit"
                    className="btn text-xs py-2 px-4 font-semibold whitespace-nowrap cursor-pointer"
                  >
                    Sign In
                  </button>
                </div>
              </form>

              {/* Roster Account Picker */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-600">
                    Or Select From Active Cohort ({allUsers.length} Users)
                  </h3>
                  <button
                    type="button"
                    onClick={() => {
                      const coordinator = allUsers.find((u) => u.role === 'coordinator');
                      if (coordinator) {
                        onSelectUser(coordinator);
                        onToast('Signed in as Coordinator Prof. Sharma');
                        onClose();
                      }
                    }}
                    className="text-xs font-bold text-purple-700 bg-purple-50 hover:bg-purple-100 border border-purple-200 px-2.5 py-1 rounded-lg transition"
                  >
                    🎓 Sign In as Coordinator (Prof. Sharma)
                  </button>
                </div>

                {/* Filter input with proper padding and icon alignment */}
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <Search className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    value={loginSearch}
                    onChange={(e) => setLoginSearch(e.target.value)}
                    placeholder="Search by student name or email..."
                    className="w-full text-xs pr-3 py-2 bg-slate-50 rounded-xl border border-slate-200 focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal-500 search-input-field"
                    style={{ paddingLeft: '2.75rem' }}
                  />
                </div>

                <div className="max-h-60 overflow-y-auto divide-y divide-slate-100 rounded-xl border border-slate-200 p-1">
                  {filteredUsers.map((u) => {
                    const prof = store.getState().studentProfiles.find((p) => p.userId === u.id);
                    return (
                      <div
                        key={u.id}
                        onClick={() => {
                          onSelectUser(u);
                          onToast(`Switched active account to ${u.name}`);
                          onClose();
                        }}
                        className="p-2.5 rounded-lg flex items-center justify-between hover:bg-teal-50/70 transition cursor-pointer"
                      >
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-lg bg-slate-100 text-slate-700 font-bold flex items-center justify-center text-xs">
                            {u.name.charAt(0)}
                          </div>
                          <div>
                            <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                              <span>{u.name}</span>
                              <span
                                className={`text-[9px] px-1.5 py-0.2 rounded font-bold uppercase ${
                                  u.role === 'coordinator'
                                    ? 'bg-purple-100 text-purple-700'
                                    : 'bg-teal-100 text-teal-700'
                                }`}
                              >
                                {u.role}
                              </span>
                            </div>
                            <div className="text-[11px] text-slate-400">{u.email}</div>
                          </div>
                        </div>

                        <div className="text-right">
                          <span className="text-[11px] text-teal-700 font-bold">
                            {u.role === 'student' ? `${store.calcGeneralScore(u.id)} / 10` : 'Admin'}
                          </span>
                          {prof?.preferredRole && (
                            <div className="text-[10px] text-slate-400 capitalize">{prof.preferredRole}</div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
